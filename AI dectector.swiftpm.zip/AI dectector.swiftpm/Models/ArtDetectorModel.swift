import SwiftUI
import Vision
import AVFoundation
import NaturalLanguage

enum AnalysisMode {
    case aiDetection
    case locationAnalysis
}

@MainActor
class MediaAnalyzer: ObservableObject {
    @Published var isProcessing = false
    @Published var aiLikelihood: Double = 0.0
    @Published var locationGuess: String = ""
    @Published var extractedText: String = ""
    @Published var currentMode: AnalysisMode = .aiDetection
    
    init() {
        // No initialization needed
    }
    
    func analyzeImage(_ image: UIImage) {
        isProcessing = true
        
        switch currentMode {
        case .aiDetection:
            // Simulate AI detection with a random value
            DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) { [weak self] in
                guard let self = self else { return }
                
                // Generate a random likelihood between 0 and 100
                let randomValue = Double.random(in: 0...100)
                self.aiLikelihood = randomValue
                self.isProcessing = false
            }
            
        case .locationAnalysis:
            // Extract text from the image using Vision framework
            extractTextFromImage(image) { [weak self] extractedText in
                guard let self = self else { return }
                
                // Analyze the extracted text to guess the location
                self.analyzeTextForLocation(extractedText)
                self.isProcessing = false
            }
        }
    }
    
    func analyzeVideo(url: URL) async {
        isProcessing = true
        
        switch currentMode {
        case .aiDetection:
            // Simulate AI detection with a random value
            try? await Task.sleep(nanoseconds: 1_000_000_000) // 1 second delay
            aiLikelihood = Double.random(in: 0...100)
            isProcessing = false
            
        case .locationAnalysis:
            // Extract a frame from the video for analysis
            let asset = AVAsset(url: url)
            let imageGenerator = AVAssetImageGenerator(asset: asset)
            imageGenerator.appliesPreferredTrackTransform = true
            
            do {
                // Get a frame from the middle of the video
                let time = CMTime(seconds: 1, preferredTimescale: 60)
                let cgImage = try imageGenerator.copyCGImage(at: time, actualTime: nil)
                let image = UIImage(cgImage: cgImage)
                
                // Extract text from the frame
                extractTextFromImage(image) { [weak self] extractedText in
                    guard let self = self else { return }
                    
                    // Analyze the extracted text to guess the location
                    self.analyzeTextForLocation(extractedText)
                    self.isProcessing = false
                }
            } catch {
                print("Error extracting frame from video: \(error.localizedDescription)")
                isProcessing = false
            }
        }
    }
    
    private func extractTextFromImage(_ image: UIImage, completion: @escaping (String) -> Void) {
        guard let cgImage = image.cgImage else {
            completion("")
            return
        }
        
        // Create a new Vision request for text recognition
        let request = VNRecognizeTextRequest { request, error in
            guard error == nil,
                  let observations = request.results as? [VNRecognizedTextObservation] else {
                completion("")
                return
            }
            
            // Extract the recognized text
            let recognizedStrings = observations.compactMap { observation in
                observation.topCandidates(1).first?.string
            }
            
            let extractedText = recognizedStrings.joined(separator: " ")
            self.extractedText = extractedText
            completion(extractedText)
        }
        
        // Configure the request
        request.recognitionLevel = .accurate
        request.usesLanguageCorrection = true
        
        // Create a request handler and perform the request
        let requestHandler = VNImageRequestHandler(cgImage: cgImage, options: [:])
        try? requestHandler.perform([request])
    }
    
    private func analyzeTextForLocation(_ text: String) {
        // Define location categories with their keywords
        let locationCategories = [
            "not a location": ["error", "unknown", "invalid", "no location", "not found"],
            "Africa": ["africa", "safari", "savanna", "desert", "pyramid", "cairo", "nairobi", "cape town"],
            "Asia": ["asia", "china", "japan", "india", "thailand", "vietnam", "korea", "singapore", "bangkok", "tokyo"],
            "Europe": ["europe", "paris", "london", "rome", "berlin", "madrid", "amsterdam", "eiffel", "colosseum"],
            "North America": ["america", "usa", "canada", "mexico", "new york", "los angeles", "chicago", "toronto"],
            "South America": ["south america", "brazil", "argentina", "peru", "chile", "colombia", "amazon", "rio"],
            "Australia": ["australia", "sydney", "melbourne", "brisbane", "perth", "outback", "great barrier reef"],
            "Antarctica": ["antarctica", "south pole", "ice", "penguin", "glacier", "arctic"],
            "Nature": ["forest", "mountain", "beach", "ocean", "river", "lake", "waterfall", "wildlife", "tree", "grass", "flower", "park", "garden", "hiking", "trail"],
            "City": ["city", "building", "street", "downtown", "urban", "skyscraper", "traffic", "road", "avenue", "plaza", "square", "district", "neighborhood"],
            "Rural": ["farm", "countryside", "village", "rural", "agriculture", "field", "crop", "barn", "pasture", "meadow"],
            "Indoor": ["room", "house", "apartment", "office", "building", "restaurant", "cafe", "store", "mall", "museum", "gallery", "theater", "hospital", "school", "university"],
            "Transportation": ["airport", "train", "station", "bus", "subway", "metro", "port", "harbor", "dock", "terminal", "runway", "platform"]
        ]
        
        // Count keyword matches for each category
        var categoryScores: [String: Int] = [:]
        
        for (category, keywords) in locationCategories {
            var score = 0
            for keyword in keywords {
                if text.lowercased().contains(keyword) {
                    score += 1
                }
            }
            categoryScores[category] = score
        }
        
        // Find the category with the highest score
        let bestCategory = categoryScores.max(by: { $0.value < $1.value })
        
        if let category = bestCategory, category.value > 0 {
            // Format the location guess
            let confidence = min(100, Int((Double(category.value) / 5.0) * 100))
            
            if category.key == "not a location" {
                locationGuess = "This image does not appear to contain location information."
            } else if ["Nature", "City", "Rural", "Indoor", "Transportation"].contains(category.key) {
                locationGuess = "This appears to be a \(category.key.lowercased()) scene (confidence: \(confidence)%)"
            } else {
                locationGuess = "This appears to be somewhere in \(category.key) (confidence: \(confidence)%)"
            }
        } else {
            locationGuess = "Unable to determine the location from the text in the image."
        }
    }
} 
