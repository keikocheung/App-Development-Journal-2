import SwiftUI
import AVFoundation

@MainActor
final class SampleMediaGenerator: @unchecked Sendable {
    static let shared = SampleMediaGenerator()
    
    private init() {}
    
    func generateSampleImage(name: String, color: UIColor) -> UIImage? {
        let size = CGSize(width: 800, height: 600)
        let renderer = UIGraphicsImageRenderer(size: size)
        
        return renderer.image { context in
            color.setFill()
            context.fill(CGRect(origin: .zero, size: size))
            
            let text = name
            let attributes: [NSAttributedString.Key: Any] = [
                .font: UIFont.systemFont(ofSize: 72),
                .foregroundColor: UIColor.black
            ]
            
            let textSize = text.size(withAttributes: attributes)
            let textRect = CGRect(
                x: (size.width - textSize.width) / 2,
                y: (size.height - textSize.height) / 2,
                width: textSize.width,
                height: textSize.height
            )
            
            text.draw(in: textRect, withAttributes: attributes)
        }
    }
    
    func generateCityStreetImage() -> UIImage? {
        let size = CGSize(width: 800, height: 600)
        let renderer = UIGraphicsImageRenderer(size: size)
        
        return renderer.image { context in
            // Background
            UIColor.gray.setFill()
            context.fill(CGRect(origin: .zero, size: size))
            
            // Main text
            let mainText = "MAIN STREET"
            let mainAttributes: [NSAttributedString.Key: Any] = [
                .font: UIFont.systemFont(ofSize: 48),
                .foregroundColor: UIColor.white
            ]
            
            let mainTextSize = mainText.size(withAttributes: mainAttributes)
            let mainTextRect = CGRect(
                x: (size.width - mainTextSize.width) / 2,
                y: (size.height - mainTextSize.height) / 2,
                width: mainTextSize.width,
                height: mainTextSize.height
            )
            
            mainText.draw(in: mainTextRect, withAttributes: mainAttributes)
            
            // Subtitle
            let subtitle = "Downtown"
            let subtitleAttributes: [NSAttributedString.Key: Any] = [
                .font: UIFont.systemFont(ofSize: 36),
                .foregroundColor: UIColor.white
            ]
            
            let subtitleSize = subtitle.size(withAttributes: subtitleAttributes)
            let subtitleRect = CGRect(
                x: (size.width - subtitleSize.width) / 2,
                y: mainTextRect.maxY + 20,
                width: subtitleSize.width,
                height: subtitleSize.height
            )
            
            subtitle.draw(in: subtitleRect, withAttributes: subtitleAttributes)
            
            // Location
            let location = "New York City"
            let locationAttributes: [NSAttributedString.Key: Any] = [
                .font: UIFont.systemFont(ofSize: 24),
                .foregroundColor: UIColor.white
            ]
            
            let locationSize = location.size(withAttributes: locationAttributes)
            let locationRect = CGRect(
                x: (size.width - locationSize.width) / 2,
                y: subtitleRect.maxY + 20,
                width: locationSize.width,
                height: locationSize.height
            )
            
            location.draw(in: locationRect, withAttributes: locationAttributes)
        }
    }
    
    func generateSchoolBuildingImage() -> UIImage? {
        let size = CGSize(width: 800, height: 600)
        let renderer = UIGraphicsImageRenderer(size: size)
        
        return renderer.image { context in
            // Background
            UIColor(red: 0.7, green: 0.9, blue: 1.0, alpha: 1.0).setFill()
            context.fill(CGRect(origin: .zero, size: size))
            
            // Main text
            let mainText = "WASHINGTON HIGH SCHOOL"
            let mainAttributes: [NSAttributedString.Key: Any] = [
                .font: UIFont.systemFont(ofSize: 48),
                .foregroundColor: UIColor.black
            ]
            
            let mainTextSize = mainText.size(withAttributes: mainAttributes)
            let mainTextRect = CGRect(
                x: (size.width - mainTextSize.width) / 2,
                y: (size.height - mainTextSize.height) / 2,
                width: mainTextSize.width,
                height: mainTextSize.height
            )
            
            mainText.draw(in: mainTextRect, withAttributes: mainAttributes)
            
            // Subtitle
            let subtitle = "Est. 1952"
            let subtitleAttributes: [NSAttributedString.Key: Any] = [
                .font: UIFont.systemFont(ofSize: 36),
                .foregroundColor: UIColor.black
            ]
            
            let subtitleSize = subtitle.size(withAttributes: subtitleAttributes)
            let subtitleRect = CGRect(
                x: (size.width - subtitleSize.width) / 2,
                y: mainTextRect.maxY + 20,
                width: subtitleSize.width,
                height: subtitleSize.height
            )
            
            subtitle.draw(in: subtitleRect, withAttributes: subtitleAttributes)
            
            // Location
            let location = "123 Education Ave"
            let locationAttributes: [NSAttributedString.Key: Any] = [
                .font: UIFont.systemFont(ofSize: 24),
                .foregroundColor: UIColor.black
            ]
            
            let locationSize = location.size(withAttributes: locationAttributes)
            let locationRect = CGRect(
                x: (size.width - locationSize.width) / 2,
                y: subtitleRect.maxY + 20,
                width: locationSize.width,
                height: locationSize.height
            )
            
            location.draw(in: locationRect, withAttributes: locationAttributes)
        }
    }
    
    func generateRestaurantSignImage() -> UIImage? {
        let size = CGSize(width: 800, height: 600)
        let renderer = UIGraphicsImageRenderer(size: size)
        
        return renderer.image { context in
            // Background
            UIColor.orange.setFill()
            context.fill(CGRect(origin: .zero, size: size))
            
            // Main text
            let mainText = "ITALIAN RESTAURANT"
            let mainAttributes: [NSAttributedString.Key: Any] = [
                .font: UIFont.systemFont(ofSize: 48),
                .foregroundColor: UIColor.white
            ]
            
            let mainTextSize = mainText.size(withAttributes: mainAttributes)
            let mainTextRect = CGRect(
                x: (size.width - mainTextSize.width) / 2,
                y: (size.height - mainTextSize.height) / 2,
                width: mainTextSize.width,
                height: mainTextSize.height
            )
            
            mainText.draw(in: mainTextRect, withAttributes: mainAttributes)
            
            // Subtitle
            let subtitle = "Authentic Cuisine"
            let subtitleAttributes: [NSAttributedString.Key: Any] = [
                .font: UIFont.systemFont(ofSize: 36),
                .foregroundColor: UIColor.white
            ]
            
            let subtitleSize = subtitle.size(withAttributes: subtitleAttributes)
            let subtitleRect = CGRect(
                x: (size.width - subtitleSize.width) / 2,
                y: mainTextRect.maxY + 20,
                width: subtitleSize.width,
                height: subtitleSize.height
            )
            
            subtitle.draw(in: subtitleRect, withAttributes: subtitleAttributes)
            
            // Hours
            let hours = "Open 11am-10pm"
            let hoursAttributes: [NSAttributedString.Key: Any] = [
                .font: UIFont.systemFont(ofSize: 24),
                .foregroundColor: UIColor.white
            ]
            
            let hoursSize = hours.size(withAttributes: hoursAttributes)
            let hoursRect = CGRect(
                x: (size.width - hoursSize.width) / 2,
                y: subtitleRect.maxY + 20,
                width: hoursSize.width,
                height: hoursSize.height
            )
            
            hours.draw(in: hoursRect, withAttributes: hoursAttributes)
        }
    }
    
    func generateTrainStationImage() -> UIImage? {
        let size = CGSize(width: 800, height: 600)
        let renderer = UIGraphicsImageRenderer(size: size)
        
        return renderer.image { context in
            // Background
            UIColor.lightGray.setFill()
            context.fill(CGRect(origin: .zero, size: size))
            
            // Main text
            let mainText = "CENTRAL STATION"
            let mainAttributes: [NSAttributedString.Key: Any] = [
                .font: UIFont.systemFont(ofSize: 48),
                .foregroundColor: UIColor.black
            ]
            
            let mainTextSize = mainText.size(withAttributes: mainAttributes)
            let mainTextRect = CGRect(
                x: (size.width - mainTextSize.width) / 2,
                y: (size.height - mainTextSize.height) / 2,
                width: mainTextSize.width,
                height: mainTextSize.height
            )
            
            mainText.draw(in: mainTextRect, withAttributes: mainAttributes)
            
            // Platform
            let platform = "Platform 9 3/4"
            let platformAttributes: [NSAttributedString.Key: Any] = [
                .font: UIFont.systemFont(ofSize: 36),
                .foregroundColor: UIColor.black
            ]
            
            let platformSize = platform.size(withAttributes: platformAttributes)
            let platformRect = CGRect(
                x: (size.width - platformSize.width) / 2,
                y: mainTextRect.maxY + 20,
                width: platformSize.width,
                height: platformSize.height
            )
            
            platform.draw(in: platformRect, withAttributes: platformAttributes)
            
            // Departures
            let departures = "Departures"
            let departuresAttributes: [NSAttributedString.Key: Any] = [
                .font: UIFont.systemFont(ofSize: 24),
                .foregroundColor: UIColor.black
            ]
            
            let departuresSize = departures.size(withAttributes: departuresAttributes)
            let departuresRect = CGRect(
                x: (size.width - departuresSize.width) / 2,
                y: platformRect.maxY + 20,
                width: departuresSize.width,
                height: departuresSize.height
            )
            
            departures.draw(in: departuresRect, withAttributes: departuresAttributes)
        }
    }
    
    func generateAirportTerminalImage() -> UIImage? {
        let size = CGSize(width: 800, height: 600)
        let renderer = UIGraphicsImageRenderer(size: size)
        
        return renderer.image { context in
            // Background
            UIColor.white.setFill()
            context.fill(CGRect(origin: .zero, size: size))
            
            // Main text
            let mainText = "INTERNATIONAL AIRPORT"
            let mainAttributes: [NSAttributedString.Key: Any] = [
                .font: UIFont.systemFont(ofSize: 48),
                .foregroundColor: UIColor.black
            ]
            
            let mainTextSize = mainText.size(withAttributes: mainAttributes)
            let mainTextRect = CGRect(
                x: (size.width - mainTextSize.width) / 2,
                y: (size.height - mainTextSize.height) / 2,
                width: mainTextSize.width,
                height: mainTextSize.height
            )
            
            mainText.draw(in: mainTextRect, withAttributes: mainAttributes)
            
            // Terminal
            let terminal = "Terminal B"
            let terminalAttributes: [NSAttributedString.Key: Any] = [
                .font: UIFont.systemFont(ofSize: 36),
                .foregroundColor: UIColor.black
            ]
            
            let terminalSize = terminal.size(withAttributes: terminalAttributes)
            let terminalRect = CGRect(
                x: (size.width - terminalSize.width) / 2,
                y: mainTextRect.maxY + 20,
                width: terminalSize.width,
                height: terminalSize.height
            )
            
            terminal.draw(in: terminalRect, withAttributes: terminalAttributes)
            
            // Gate
            let gate = "Gate 42"
            let gateAttributes: [NSAttributedString.Key: Any] = [
                .font: UIFont.systemFont(ofSize: 24),
                .foregroundColor: UIColor.black
            ]
            
            let gateSize = gate.size(withAttributes: gateAttributes)
            let gateRect = CGRect(
                x: (size.width - gateSize.width) / 2,
                y: terminalRect.maxY + 20,
                width: gateSize.width,
                height: gateSize.height
            )
            
            gate.draw(in: gateRect, withAttributes: gateAttributes)
        }
    }
    
    func generateNatureTrailImage() -> UIImage? {
        let size = CGSize(width: 800, height: 600)
        let renderer = UIGraphicsImageRenderer(size: size)
        
        return renderer.image { context in
            // Background
            UIColor.green.setFill()
            context.fill(CGRect(origin: .zero, size: size))
            
            // Main text
            let mainText = "MOUNTAIN TRAIL"
            let mainAttributes: [NSAttributedString.Key: Any] = [
                .font: UIFont.systemFont(ofSize: 48),
                .foregroundColor: UIColor.white
            ]
            
            let mainTextSize = mainText.size(withAttributes: mainAttributes)
            let mainTextRect = CGRect(
                x: (size.width - mainTextSize.width) / 2,
                y: (size.height - mainTextSize.height) / 2,
                width: mainTextSize.width,
                height: mainTextSize.height
            )
            
            mainText.draw(in: mainTextRect, withAttributes: mainAttributes)
            
            // Difficulty
            let difficulty = "Difficulty: Moderate"
            let difficultyAttributes: [NSAttributedString.Key: Any] = [
                .font: UIFont.systemFont(ofSize: 36),
                .foregroundColor: UIColor.white
            ]
            
            let difficultySize = difficulty.size(withAttributes: difficultyAttributes)
            let difficultyRect = CGRect(
                x: (size.width - difficultySize.width) / 2,
                y: mainTextRect.maxY + 20,
                width: difficultySize.width,
                height: difficultySize.height
            )
            
            difficulty.draw(in: difficultyRect, withAttributes: difficultyAttributes)
            
            // Distance
            let distance = "2.5 miles"
            let distanceAttributes: [NSAttributedString.Key: Any] = [
                .font: UIFont.systemFont(ofSize: 24),
                .foregroundColor: UIColor.white
            ]
            
            let distanceSize = distance.size(withAttributes: distanceAttributes)
            let distanceRect = CGRect(
                x: (size.width - distanceSize.width) / 2,
                y: difficultyRect.maxY + 20,
                width: distanceSize.width,
                height: distanceSize.height
            )
            
            distance.draw(in: distanceRect, withAttributes: distanceAttributes)
        }
    }
    
    func generateShoppingMallImage() -> UIImage? {
        let size = CGSize(width: 800, height: 600)
        let renderer = UIGraphicsImageRenderer(size: size)
        
        return renderer.image { context in
            // Background
            UIColor(red: 1.0, green: 0.8, blue: 0.9, alpha: 1.0).setFill()
            context.fill(CGRect(origin: .zero, size: size))
            
            // Main text
            let mainText = "SHOPPING MALL"
            let mainAttributes: [NSAttributedString.Key: Any] = [
                .font: UIFont.systemFont(ofSize: 48),
                .foregroundColor: UIColor.black
            ]
            
            let mainTextSize = mainText.size(withAttributes: mainAttributes)
            let mainTextRect = CGRect(
                x: (size.width - mainTextSize.width) / 2,
                y: (size.height - mainTextSize.height) / 2,
                width: mainTextSize.width,
                height: mainTextSize.height
            )
            
            mainText.draw(in: mainTextRect, withAttributes: mainAttributes)
            
            // Hours
            let hours = "Open 10am-9pm"
            let hoursAttributes: [NSAttributedString.Key: Any] = [
                .font: UIFont.systemFont(ofSize: 36),
                .foregroundColor: UIColor.black
            ]
            
            let hoursSize = hours.size(withAttributes: hoursAttributes)
            let hoursRect = CGRect(
                x: (size.width - hoursSize.width) / 2,
                y: mainTextRect.maxY + 20,
                width: hoursSize.width,
                height: hoursSize.height
            )
            
            hours.draw(in: hoursRect, withAttributes: hoursAttributes)
            
            // Food Court
            let foodCourt = "Food Court Level 2"
            let foodCourtAttributes: [NSAttributedString.Key: Any] = [
                .font: UIFont.systemFont(ofSize: 24),
                .foregroundColor: UIColor.black
            ]
            
            let foodCourtSize = foodCourt.size(withAttributes: foodCourtAttributes)
            let foodCourtRect = CGRect(
                x: (size.width - foodCourtSize.width) / 2,
                y: hoursRect.maxY + 20,
                width: foodCourtSize.width,
                height: foodCourtSize.height
            )
            
            foodCourt.draw(in: foodCourtRect, withAttributes: foodCourtAttributes)
        }
    }
    
    func saveImage(_ image: UIImage, name: String) {
        if let data = image.jpegData(compressionQuality: 0.8) {
            let url = getDocumentsDirectory().appendingPathComponent(name)
            try? data.write(to: url)
        }
    }
    
    private func getDocumentsDirectory() -> URL {
        FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
    }
} 