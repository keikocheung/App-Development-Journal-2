#!/bin/bash

# Create sample images
convert -size 800x600 xc:white -gravity center -pointsize 72 -annotate 0 "Sample Image 1" sample1.jpg
convert -size 800x600 xc:blue -gravity center -pointsize 72 -annotate 0 "Sample Image 2" sample2.jpg
convert -size 800x600 xc:green -gravity center -pointsize 72 -annotate 0 "Sample Image 3" sample3.jpg

# Create city street image with text
convert -size 800x600 xc:gray -gravity center -pointsize 48 -annotate 0 "MAIN STREET" -pointsize 36 -annotate +0+100 "Downtown" -pointsize 24 -annotate +0+150 "New York City" city_street.jpg

# Create school building image with text
convert -size 800x600 xc:lightblue -gravity center -pointsize 48 -annotate 0 "WASHINGTON HIGH SCHOOL" -pointsize 36 -annotate +0+100 "Est. 1952" -pointsize 24 -annotate +0+150 "123 Education Ave" school_building.jpg

# Create restaurant sign image with text
convert -size 800x600 xc:orange -gravity center -pointsize 48 -annotate 0 "ITALIAN RESTAURANT" -pointsize 36 -annotate +0+100 "Authentic Cuisine" -pointsize 24 -annotate +0+150 "Open 11am-10pm" restaurant_sign.jpg

# Create train station image with text
convert -size 800x600 xc:lightgray -gravity center -pointsize 48 -annotate 0 "CENTRAL STATION" -pointsize 36 -annotate +0+100 "Platform 9 3/4" -pointsize 24 -annotate +0+150 "Departures" train_station.jpg

# Create airport terminal image with text
convert -size 800x600 xc:white -gravity center -pointsize 48 -annotate 0 "INTERNATIONAL AIRPORT" -pointsize 36 -annotate +0+100 "Terminal B" -pointsize 24 -annotate +0+150 "Gate 42" airport_terminal.jpg

# Create nature trail image with text
convert -size 800x600 xc:green -gravity center -pointsize 48 -annotate 0 "MOUNTAIN TRAIL" -pointsize 36 -annotate +0+100 "Difficulty: Moderate" -pointsize 24 -annotate +0+150 "2.5 miles" nature_trail.jpg

# Create shopping mall image with text
convert -size 800x600 xc:lightpink -gravity center -pointsize 48 -annotate 0 "SHOPPING MALL" -pointsize 36 -annotate +0+100 "Open 10am-9pm" -pointsize 24 -annotate +0+150 "Food Court Level 2" shopping_mall.jpg

# Create sample videos (5 seconds each)
ffmpeg -f lavfi -i color=c=white:s=800x600:d=5 -vf "drawtext=text='Sample Video 1':fontsize=72:fontcolor=black:x=(w-text_w)/2:y=(h-text_h)/2" sample1.mp4
ffmpeg -f lavfi -i color=c=blue:s=800x600:d=5 -vf "drawtext=text='Sample Video 2':fontsize=72:fontcolor=white:x=(w-text_w)/2:y=(h-text_h)/2" sample2.mp4

# Create sample audio files (5 seconds each)
ffmpeg -f lavfi -i "sine=frequency=440:duration=5" sample1.m4a
ffmpeg -f lavfi -i "sine=frequency=880:duration=5" sample2.m4a 