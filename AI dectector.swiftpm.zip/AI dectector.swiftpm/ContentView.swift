import SwiftUI
import PhotosUI
import AVKit
import UniformTypeIdentifiers

struct ContentView: View {
    @StateObject private var analyzer = MediaAnalyzer()
    @State private var selectedItem: PhotosPickerItem?
    @State private var selectedImage: UIImage?
    @State private var selectedVideo: URL?
    @State private var showResult = false
    
    var body: some View {
        NavigationView {
            VStack(spacing: 20) {
                // Analysis Mode Picker
                Picker("Analysis Mode", selection: $analyzer.currentMode) {
                    Text("AI Detection").tag(AnalysisMode.aiDetection)
                    Text("Location Analysis").tag(AnalysisMode.locationAnalysis)
                }
                .pickerStyle(SegmentedPickerStyle())
                .padding(.horizontal)
                
                // Media Preview
                if let image = selectedImage {
                    Image(uiImage: image)
                        .resizable()
                        .scaledToFit()
                        .frame(maxHeight: 300)
                        .cornerRadius(12)
                } else if let videoURL = selectedVideo {
                    VideoPlayer(player: AVPlayer(url: videoURL))
                        .frame(height: 300)
                        .cornerRadius(12)
                } else {
                    Image(systemName: "photo")
                        .resizable()
                        .scaledToFit()
                        .frame(maxHeight: 200)
                        .foregroundColor(.gray)
                        .padding()
                }
                
                // Sample Media Section
                VStack(alignment: .leading, spacing: 10) {
                    Text("Sample Media")
                        .font(.headline)
                        .padding(.horizontal)
                    
                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack(spacing: 10) {
                            // Sample Images
                            Button(action: {
                                if let image = SampleMediaGenerator.shared.generateSampleImage(name: "Sample Image 1", color: .white) {
                                    selectedImage = image
                                    selectedVideo = nil
                                    analyzer.analyzeImage(image)
                                }
                            }) {
                                Text("Sample Image 1")
                                    .font(.caption)
                                    .foregroundColor(.white)
                                    .padding()
                                    .background(Color.blue)
                                    .cornerRadius(10)
                            }
                            
                            Button(action: {
                                if let image = SampleMediaGenerator.shared.generateSampleImage(name: "Sample Image 2", color: .blue) {
                                    selectedImage = image
                                    selectedVideo = nil
                                    analyzer.analyzeImage(image)
                                }
                            }) {
                                Text("Sample Image 2")
                                    .font(.caption)
                                    .foregroundColor(.white)
                                    .padding()
                                    .background(Color.blue)
                                    .cornerRadius(10)
                            }
                            
                            Button(action: {
                                if let image = SampleMediaGenerator.shared.generateSampleImage(name: "Sample Image 3", color: .green) {
                                    selectedImage = image
                                    selectedVideo = nil
                                    analyzer.analyzeImage(image)
                                }
                            }) {
                                Text("Sample Image 3")
                                    .font(.caption)
                                    .foregroundColor(.white)
                                    .padding()
                                    .background(Color.blue)
                                    .cornerRadius(10)
                            }
                            
                            // New Sample Images with Text
                            Button(action: {
                                if let image = SampleMediaGenerator.shared.generateCityStreetImage() {
                                    selectedImage = image
                                    selectedVideo = nil
                                    analyzer.analyzeImage(image)
                                }
                            }) {
                                Text("City Street")
                                    .font(.caption)
                                    .foregroundColor(.white)
                                    .padding()
                                    .background(Color.blue)
                                    .cornerRadius(10)
                            }
                            
                            Button(action: {
                                if let image = SampleMediaGenerator.shared.generateSchoolBuildingImage() {
                                    selectedImage = image
                                    selectedVideo = nil
                                    analyzer.analyzeImage(image)
                                }
                            }) {
                                Text("School")
                                    .font(.caption)
                                    .foregroundColor(.white)
                                    .padding()
                                    .background(Color.blue)
                                    .cornerRadius(10)
                            }
                            
                            Button(action: {
                                if let image = SampleMediaGenerator.shared.generateRestaurantSignImage() {
                                    selectedImage = image
                                    selectedVideo = nil
                                    analyzer.analyzeImage(image)
                                }
                            }) {
                                Text("Restaurant")
                                    .font(.caption)
                                    .foregroundColor(.white)
                                    .padding()
                                    .background(Color.blue)
                                    .cornerRadius(10)
                            }
                            
                            Button(action: {
                                if let image = SampleMediaGenerator.shared.generateTrainStationImage() {
                                    selectedImage = image
                                    selectedVideo = nil
                                    analyzer.analyzeImage(image)
                                }
                            }) {
                                Text("Train Station")
                                    .font(.caption)
                                    .foregroundColor(.white)
                                    .padding()
                                    .background(Color.blue)
                                    .cornerRadius(10)
                            }
                            
                            Button(action: {
                                if let image = SampleMediaGenerator.shared.generateAirportTerminalImage() {
                                    selectedImage = image
                                    selectedVideo = nil
                                    analyzer.analyzeImage(image)
                                }
                            }) {
                                Text("Airport")
                                    .font(.caption)
                                    .foregroundColor(.white)
                                    .padding()
                                    .background(Color.blue)
                                    .cornerRadius(10)
                            }
                            
                            Button(action: {
                                if let image = SampleMediaGenerator.shared.generateNatureTrailImage() {
                                    selectedImage = image
                                    selectedVideo = nil
                                    analyzer.analyzeImage(image)
                                }
                            }) {
                                Text("Nature Trail")
                                    .font(.caption)
                                    .foregroundColor(.white)
                                    .padding()
                                    .background(Color.blue)
                                    .cornerRadius(10)
                            }
                            
                            Button(action: {
                                if let image = SampleMediaGenerator.shared.generateShoppingMallImage() {
                                    selectedImage = image
                                    selectedVideo = nil
                                    analyzer.analyzeImage(image)
                                }
                            }) {
                                Text("Shopping Mall")
                                    .font(.caption)
                                    .foregroundColor(.white)
                                    .padding()
                                    .background(Color.blue)
                                    .cornerRadius(10)
                            }
                        }
                        .padding(.horizontal)
                    }
                }
                
                // Media Selection Button
                PhotosPicker(selection: $selectedItem,
                           matching: .images,
                           photoLibrary: .shared()) {
                    Text("Select Image")
                        .font(.headline)
                        .foregroundColor(.white)
                        .padding()
                        .background(Color.blue)
                        .cornerRadius(10)
                }
                
                // Results
                if analyzer.isProcessing {
                    ProgressView("Analyzing media...")
                        .padding()
                }
                
                Spacer()
            }
            .padding()
            .navigationTitle(analyzer.currentMode == .aiDetection ? "AI Detector" : "Location Detector")
            .onChange(of: selectedItem) { newItem in
                Task {
                    await handleSelectedItem(newItem)
                }
            }
            .onChange(of: analyzer.aiLikelihood) { newValue in
                if newValue > 0 && !analyzer.isProcessing {
                    showResult = true
                }
            }
            .onChange(of: analyzer.locationGuess) { newValue in
                if !newValue.isEmpty && !analyzer.isProcessing {
                    showResult = true
                }
            }
            .alert(analyzer.currentMode == .aiDetection ? "AI Detection Result" : "Location Analysis Result", isPresented: $showResult) {
                Button("OK", role: .cancel) { }
            } message: {
                VStack(alignment: .leading) {
                    if analyzer.currentMode == .aiDetection {
                        Text("This media is \(Int(analyzer.aiLikelihood))% likely to be AI-generated.")
                    } else {
                        if !analyzer.locationGuess.isEmpty {
                            Text(analyzer.locationGuess)
                        }
                        
                        if !analyzer.extractedText.isEmpty {
                            Text("\nExtracted Text:")
                                .font(.headline)
                            Text(analyzer.extractedText)
                                .font(.caption)
                        }
                    }
                }
            }
        }
    }
    
    private func handleSelectedItem(_ item: PhotosPickerItem?) async {
        guard let item = item else { return }
        
        // Try loading as image
        if let data = try? await item.loadTransferable(type: Data.self),
           let image = UIImage(data: data) {
            selectedImage = image
            selectedVideo = nil
            analyzer.analyzeImage(image)
            return
        }
    }
}
