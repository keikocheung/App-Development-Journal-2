import SwiftUI

@main
struct RealOrRenderedApp: App {
    init() {
        // Initialize sample media
        Task {
            await SampleMediaInitializer.shared.initializeSampleMedia()
        }
    }
    
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
