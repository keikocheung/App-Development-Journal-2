import SwiftUI
import AVFoundation

@MainActor
final class SampleMediaLoader: @unchecked Sendable {
    static let shared = SampleMediaLoader()
    
    private init() {}
    
    // Sample image URLs
    let sampleImages = [
        "sample1.jpg",
        "sample2.jpg",
        "sample3.jpg",
        "city_street.jpg",
        "school_building.jpg",
        "restaurant_sign.jpg",
        "train_station.jpg",
        "airport_terminal.jpg",
        "nature_trail.jpg",
        "shopping_mall.jpg"
    ]
    
    // Sample video URLs
    let sampleVideos = [
        "sample1.mp4",
        "sample2.mp4"
    ]
    
    // Sample audio URLs
    let sampleAudio = [
        "sample1.m4a",
        "sample2.m4a"
    ]
    
    func getSampleImageURL(_ name: String) -> URL? {
        Bundle.main.url(forResource: name.replacingOccurrences(of: ".jpg", with: ""), withExtension: "jpg")
    }
    
    func getSampleVideoURL(_ name: String) -> URL? {
        Bundle.main.url(forResource: name.replacingOccurrences(of: ".mp4", with: ""), withExtension: "mp4")
    }
    
    func getSampleAudioURL(_ name: String) -> URL? {
        Bundle.main.url(forResource: name.replacingOccurrences(of: ".m4a", with: ""), withExtension: "m4a")
    }
} 
