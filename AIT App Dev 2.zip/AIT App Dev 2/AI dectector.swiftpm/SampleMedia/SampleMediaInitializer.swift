import SwiftUI

@MainActor
final class SampleMediaInitializer: @unchecked Sendable {
    static let shared = SampleMediaInitializer()
    
    private init() {}
    
    func initializeSampleMedia() {
        // Generate and save the new sample images
        if let cityStreetImage = SampleMediaGenerator.shared.generateCityStreetImage() {
            SampleMediaGenerator.shared.saveImage(cityStreetImage, name: "city_street.jpg")
        }
        
        if let schoolBuildingImage = SampleMediaGenerator.shared.generateSchoolBuildingImage() {
            SampleMediaGenerator.shared.saveImage(schoolBuildingImage, name: "school_building.jpg")
        }
        
        if let restaurantSignImage = SampleMediaGenerator.shared.generateRestaurantSignImage() {
            SampleMediaGenerator.shared.saveImage(restaurantSignImage, name: "restaurant_sign.jpg")
        }
        
        if let trainStationImage = SampleMediaGenerator.shared.generateTrainStationImage() {
            SampleMediaGenerator.shared.saveImage(trainStationImage, name: "train_station.jpg")
        }
        
        if let airportTerminalImage = SampleMediaGenerator.shared.generateAirportTerminalImage() {
            SampleMediaGenerator.shared.saveImage(airportTerminalImage, name: "airport_terminal.jpg")
        }
        
        if let natureTrailImage = SampleMediaGenerator.shared.generateNatureTrailImage() {
            SampleMediaGenerator.shared.saveImage(natureTrailImage, name: "nature_trail.jpg")
        }
        
        if let shoppingMallImage = SampleMediaGenerator.shared.generateShoppingMallImage() {
            SampleMediaGenerator.shared.saveImage(shoppingMallImage, name: "shopping_mall.jpg")
        }
        
        // Generate and save the original sample images
        if let sample1Image = SampleMediaGenerator.shared.generateSampleImage(name: "Sample Image 1", color: .white) {
            SampleMediaGenerator.shared.saveImage(sample1Image, name: "sample1.jpg")
        }
        
        if let sample2Image = SampleMediaGenerator.shared.generateSampleImage(name: "Sample Image 2", color: .blue) {
            SampleMediaGenerator.shared.saveImage(sample2Image, name: "sample2.jpg")
        }
        
        if let sample3Image = SampleMediaGenerator.shared.generateSampleImage(name: "Sample Image 3", color: .green) {
            SampleMediaGenerator.shared.saveImage(sample3Image, name: "sample3.jpg")
        }
    }
} 